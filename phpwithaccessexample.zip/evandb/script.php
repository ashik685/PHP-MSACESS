<?php
/**
 * Created by Syed Ashik Mahmud
 * User: Even
 * Date: 26-Apr-17
 * Time: 3:07 AM
 */
include_once ($_SERVER["DOCUMENT_ROOT"].'/evandb/config/config.php');

$cableLength = $_POST['cableLength'];
$serialNumber = $_POST['serialNumber'];
$date = $_POST['date'];
$voltageIn = $_POST['voltageIn'];
$voltageOut = $_POST['voltageOut'];
$current = $_POST['current'];

//echo $date;


// Check for duplicate entry

/*$sql = "SELECT count(*) FROM [20 Amp Cable] WHERE [Serial Number]='$serialNumber'";
$result = $db->query($sql);*/

//$nRows = $pdo->query('select count(*) from [20 Amp Cable]')->fetchColumn(); echo $nRows;


/*if($result > 1) {

    echo '<div class="alert alert-danger">  <strong>Sorry!</strong> Serial Number Already Exists.</div>';

}

else {
*/
//Enter data to Access Database

    $sql = "INSERT INTO [20 Amp Cable]([Cable Length],[Serial Number],[Date],[Voltage In],[Voltage Out],[Current]) VALUES ('$cableLength','$serialNumber','$date','$voltageIn','$voltageOut','$current')";

//$sql = "INSERT INTO [20 Amp Cable]([Cable Length],[Serial Number]) VALUES ('5A','247889')";
    $db->query($sql);

    echo '<div class="alert alert-warning"><strong>Success !!!</strong> You have added a new data.</div>';


/* } */

?>