<?php
/**
 * Created by Syed Ashik Mahmud
 * User: Even
 * Date: 26-Apr-17
 * Time: 3:07 AM
 */
include_once ($_SERVER["DOCUMENT_ROOT"].'/evandb/config/config.php');

$sql = "SELECT * FROM [20 Amp Cable]";
$result = $db->query($sql);
while ($row = $result->fetch()) {
    echo $row["Cable Length"].'<br/>';
}