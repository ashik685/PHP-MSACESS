<?php
/**
 * Created by Syed Ashik Mahmud
 * User: Even
 * Date: 26-Apr-17
 * Time: 3:07 AM
 */

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>20 Amp Cable Form</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Style -->

    <link href="css/style.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,700,700i" rel="stylesheet">



    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>

    <div class="container bootstrap-iso"">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="text-center heading">20 Amp Cable Entry Form</h1>
                <form method="post" action="script.php" id="entry">

                    <div class="form-group row">
                        <label for="exampleSelect1" class="col-lg-2 col-form-label">Cable Length</label>
                        <div class="col-lg-10">
                            <select class="form-control" id="cableLength" name="cableLength">
                                <option>1A</option>
                                <option>1B</option>
                                <option>2A</option>
                                <option>2B</option>
                                <option>3A</option>
                                <option>3B</option>
                                <option>4A</option>
                                <option>4B</option>
                                <option>5A</option>
                                <option>5B</option>
                            </select>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label for="example-number-input" class="col-lg-2 col-form-label">Serial Number</label>
                        <div class="col-lg-10">
                            <input class="form-control" type="text" value="" id="serialNumber" name="serialNumber" data-validation="required">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="example-text-input" class="col-lg-2 col-form-label">Date</label>
                        <div class="col-lg-10">
                            <div class="input-group">
                                <input class="form-control" id="date" name="date" placeholder="dd-M-yy" type="text"/>
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-th"></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="example-text-input" class="col-lg-2 col-form-label">Voltage In</label>
                        <div class="col-lg-10">
                            <input class="form-control" type="text" value="" id="voltageIn" name="voltageIn" data-validation="required">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="example-text-input" class="col-lg-2 col-form-label">Voltage Out</label>
                        <div class="col-lg-10">
                            <input class="form-control" type="text" value="" id="voltageOut" name="voltageOut" data-validation="required">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="exampleSelect1" class="col-lg-2 col-form-label">Current</label>
                        <div class="col-lg-10">
                            <select class="form-control" id="current" name="current">
                                <option>16 Amps</option>
                                <option>80 Amps</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="example-text-input" class="col-lg-2 col-form-label"></label>
                        <div class="col-lg-10">
                              <input type="submit" name="submit" value="Save and New Record" class="btn btn-primary">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="example-text-input" class="col-lg-2 col-form-label"></label>
                        <div class="col-lg-10" id="success"></div>
                    </div>





                </form>
            </div>
        </div>
    </div>


    <!-- Extra JavaScript/CSS added manually in "Settings" tab -->
    <!-- Include jQuery -->
    <script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>

    <script src="js/jquery.form-validator.min.js"></script>

    <!-- Include Date Range Picker -->
    <script type="text/javascript" src="js/bootstrap-datepicker.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap-datepicker3.css"/>

    <script>
        $(document).ready(function(){
            var date_input=$('input[name="date"]'); //our date input has the name "date"
            var container=$('.container form').length>0 ? $('.container form').parent() : "body";
            date_input.datepicker({
                format: 'dd-M-yy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        });

        $.validate({
            form : '#entry',
            onSuccess : function($form) {

                $.post("script.php",
                    {
                        cableLength: $('#cableLength').val(),
                        serialNumber: $('#serialNumber').val(),
                        date: $('#date').val(),
                        voltageIn: $('#voltageIn').val(),
                        voltageOut: $('#voltageOut').val(),
                        current: $('#current').val()
                    },
                    function(data, status){
                        //alert("Data: " + data + "\nStatus: " + status);
                        $('#success').html(data);
                    });

                return false; // Will stop the submission of the form
            }
        });

        $('#entry')[0].reset();

    </script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>


</body>
</html>
