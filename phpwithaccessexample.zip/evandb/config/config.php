<?php

/**
 * Created by Syed Ashik Mahmud
 * User: Even
 * Date: 26-Apr-17
 * Time: 3:07 AM
 */


$dbName = $_SERVER["DOCUMENT_ROOT"] . "/evandb/20amp.accdb";
//echo $dbName."<br />";

if (!file_exists($dbName)) {
    die("Could not find database file.<br />".$dbName);
}


try {
    $db = new PDO("odbc:DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};;Dbq=$dbName");
}

catch(PDOException $e) {
    echo "Error: ".$e->getMessage()."<br />";
}

?>